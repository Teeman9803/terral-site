# v1.2.0
## 11/12/2015

1. [](#new)
    * Fix for responsive videos
    * Couple fixes for JSComments
    * SimpleForm replaced with Forms plugin

# v1.1.2
## 09/21/2015

1. [](#improved)
    * improved default layout
    * improved SimpleForm compatibility
    * improved Grav compatibility
    * minor fixes

# v1.1.1
## 09/04/2015

1. [](#improved)
    * use https instead of http

# v1.1.0
## 08/25/2015

1. [](#improved)
    * Added blueprints for Grav Admin plugin

# v1.1.0
## 08/25/2015

1. [](#improved)
    * Added blueprints for Grav Admin plugin

# v1.0.1
## 04/07/2015

1. [](#bugfix)
    * Fixed for Grav 0.9.21 compatibility

# v1.0.0
## 04/07/2015

1. [](#new)
    * ChangeLog started...
