---
title: Login

form:
    name: login
    action:
    method: post

    fields:
        - name: username
          type: text
          placeholder: Username
          autofocus: true

        - name: password
          type: password
          placeholder: Password
---

# User Login

This page is restricted...
